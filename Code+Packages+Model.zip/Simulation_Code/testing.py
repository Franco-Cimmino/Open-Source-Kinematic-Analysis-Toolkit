import numpy as np
import pybullet as p # type: ignore
import pybullet_data # type: ignore
import pandas as pd
import time
import math
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.widgets import Slider
from scipy.spatial.transform import Rotation as R
import matplotlib.animation as animation
from matplotlib.widgets import CheckButtons

"""""index
Key for which joint index is which:
Joint 1: chest_joint Index=0

Shoulder joint:
Joint 2: humerus_joint_roll Index=1  flexion/extension
Joint 3: humerus_joint_yaw Index=2 internal/external rotation
Joint 4: humerus_joint Index=3 abduction/adduction

Elbow joint:
Joint 5: elbow_joint Index=4 Flexion/extension

Wrist joint:
Joint 6: wrist_joint_roll index=5  internal/external rotation
Joint 7: wrist_joint_yaw Index=6 flexion/extension
Joint 8: wrist_joint Index=7 abduction/adduction
"""""

def simulation_model():
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    gravity = p.setGravity(0, 0, -9.81)
    p.setRealTimeSimulation(1)
    
    modelStartPos = [0, 0, 0]
    modelStartOrientation = p.getQuaternionFromEuler([0, 0, 0])
    testmodel = p.loadSDF("Human_Shoulder.sdf")[0]
    
    cameraDistance = 1.18
    cameraYaw = -81.60
    cameraPitch = 8.20
    cameraTargetPosition = [0.40, 0.18, 0.46] ##camera position

    p.resetDebugVisualizerCamera(cameraDistance, cameraYaw, cameraPitch, cameraTargetPosition)
    
    return modelStartPos, modelStartOrientation, testmodel

def joint_info(testmodel, current_time):
    numJoints = p.getNumJoints(testmodel)
    joint_positions = []
    joint_torques = []
    joint_reaction_forces = []
    joint_cartesian_coordinates = []
    
    for jointIndex in range(numJoints):
        jointInfo = p.getJointInfo(testmodel, jointIndex)
        jointName = jointInfo[1].decode("UTF-8")
        jointIndex = jointInfo[0]
        
        p.enableJointForceTorqueSensor(testmodel, jointIndex)
        
        jointState = p.getJointState(testmodel, jointIndex)
        jointPosition, jointVelocity, jointReactionForces, appliedJointMotorTorque = jointState[:4]
        degreesconverted = math.degrees(jointPosition)
        
        joint_positions.append(degreesconverted)
        joint_torques.append(appliedJointMotorTorque)
        joint_reaction_forces.append(jointReactionForces)
        
        link_state = p.getLinkState(testmodel, jointIndex)
        cartesian_coordinates = link_state[0]
        joint_cartesian_coordinates.append(cartesian_coordinates)
            
        # Print joint information
        print(f"\n Joint {jointIndex+1}: {jointName}")
        print(f"\tJoint: {jointName} (Index: {jointIndex})")
        print(f"\t\tAngle in degrees relative to parent link: {degreesconverted:.4f}")
        ##print(f"\t\tVelocity: Radians per second {jointVelocity:.4f}")
        ##print(f"\t\tReaction Forces Fx, Fy, Fz, Mx, My, Mz: {jointReactionForces}")
        ##print(f"\t\tApplied Joint Motor Torque in Newton-meters (Nm): {appliedJointMotorTorque}")
        print(f"\t\tCartesian Coordinates (x, y, z): {cartesian_coordinates}")
        
    return joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates


# def plot_motor_torque_over_time(joint_torques_timeline, figsize=(8, 6)): ##just not working/too much time to figure out
#     print("Plotting applied joint motor torque over time")
    
#     joint_torques_array = np.array(joint_torques_timeline)
#     num_joints = joint_torques_array.shape[1]
    
#     plt.figure(figsize=figsize)
    
#     time_steps = np.arange(joint_torques_array.shape[0]) * 0.01  # Time steps in seconds
#     for joint_index in range(num_joints):
#         plt.plot(time_steps, joint_torques_array[:, joint_index], label=f'Joint {joint_index + 1}')
    
#     plt.xlabel('Time (s)')
#     plt.ylabel('Applied Joint Motor Torque (Nm)')
#     plt.legend()
#     plt.grid(True)
#     plt.show()


def angle_plotting(joint_positions_timeline, figsize=(8, 6)): 
    joint_positions_array = np.array(joint_positions_timeline)
    num_joints = joint_positions_array.shape[1]
    
    # Start plotting from 2 seconds onward
    start_index = int(2 / 0.01)  # Calculate the index for 2 seconds
    joint_positions_array = joint_positions_array[start_index:]
    
    fig, ax = plt.subplots(figsize=figsize)
    plt.subplots_adjust(bottom=0.3)  # Adjust the subplot to make space for checkboxes
    
    # Updated joint names without j0
    joint_names = ['J1: Flex/Ext', 'J2: Int/Ext Rotation', 'J3: Abd/Add', 
                   'J4: Flex/Ext', 'J5: Pro/Sup', 'J6: Flex/Ext', 'J7: Ulnar/Rad Deviation']
    
    # Adjust time steps to start from 2 seconds
    time_steps = np.arange(joint_positions_array.shape[0]) * 0.01 + 2.0
    
    lines = []
    for joint_index in range(1, num_joints):  # Start from 1 to exclude j0
        line, = ax.plot(time_steps, joint_positions_array[:, joint_index], label=joint_names[joint_index - 1])
        lines.append(line)
    
    # Calculate the total angular change for each joint (excluding j0)
    angular_changes = joint_positions_array[-1, 1:] - joint_positions_array[0, 1:]
    
    # Annotate the total angular change for each joint at the end of the plot
    for i, change in enumerate(angular_changes):
        ax.text(time_steps[-1], joint_positions_array[-1, i+1], f'{joint_names[i]}: {change:.2f}°', 
                ha='left', va='bottom', fontsize=9, color='black', 
                bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))
    
    plt.xlabel('Time (s)')
    plt.ylabel('Joint Position (degrees)')
    plt.legend()
    plt.grid(True)
    
    # Add check buttons
    rax = plt.axes([0.1, 0.05, 0.3, 0.15])
    labels = [joint_names[i] for i in range(num_joints - 1)]  # Adjust labels accordingly
    visibility = [line.get_visible() for line in lines]
    check = CheckButtons(rax, labels, visibility)
    
    def func(label):
        index = labels.index(label)
        lines[index].set_visible(not lines[index].get_visible())
        plt.draw()
    
    check.on_clicked(func)
    
    plt.show()
    return joint_names, time_steps




def endpoints():
    shoulder_x = 0.417999952333048
    shoulder_y = 0.2699994365684688
    shoulder_z = 0.6

    elbow_x = 0.417999952333048
    elbow_y = 0.2699994365684688 
    elbow_z = 0.302

    wrist_x = 0.417999952333048 
    wrist_y = 0.2699994365684688 
    wrist_z = 0.028
    
    hand_x = 0.417999952333048
    hand_y = 0.2699994365684688
    hand_z = -0.15305
    
    humerus_length = math.sqrt((elbow_x - shoulder_x)**2 + (elbow_y - shoulder_y)**2 + (elbow_z - shoulder_z)**2)
    forearm_length = math.sqrt((wrist_x - elbow_x)**2 + (wrist_y - elbow_y)**2 + (wrist_z - elbow_z)**2)
    hand_length = math.sqrt((hand_x - wrist_x)**2 + (hand_y - wrist_y )**2 + (hand_z - wrist_z )**2)
    
    
    shoulder_position = [shoulder_x, shoulder_y, shoulder_z]
    elbow_position = [elbow_x, elbow_y, elbow_z]
    wrist_position = [wrist_x, wrist_y, wrist_z]
    hand_position = [hand_x, hand_x, hand_y]
    
    visual_shape_id = p.createVisualShape(p.GEOM_SPHERE, radius=0.05, rgbaColor=[1, 0, 0, 1])
    ball_id = p.createMultiBody(baseMass=0, baseVisualShapeIndex=visual_shape_id, basePosition=[0,0,0])

    return shoulder_position, elbow_position, wrist_position, humerus_length, forearm_length, hand_length


##DH notations for forward kineamtics 
def rotation_matrix_y(angle):
    cos_a = math.cos(angle)
    sin_a = math.sin(angle)
    return np.array([
        [cos_a, 0, sin_a],
        [0, 1, 0],
        [-sin_a, 0, cos_a]
    ])

def rotation_matrix_x(angle):
    cos_a = math.cos(angle)
    sin_a = math.sin(angle)
    return np.array([
        [1, 0, 0],
        [0, cos_a, -sin_a],
        [0, sin_a, cos_a]
    ])

def rotation_matrix_z(angle):
    cos_a = math.cos(angle)

    sin_a = math.sin(angle)
    return np.array([
        [cos_a, -sin_a, 0],
        [sin_a, cos_a, 0],
        [0, 0, 1]
    ])

def trajectory(joint_positions_timeline, humerus_length, forearm_length, shoulder_position, hand_length):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    axcolor = 'lightgoldenrodyellow'
    ax_time = plt.axes([0.2, 0.1, 0.65, 0.03], facecolor=axcolor)
    
    time_slider = Slider(ax_time, 'Time Point', 0, len(joint_positions_timeline) - 1, valinit=0, valstep=1)
    
    x_range = [-0.2, 1]
    y_range = [-0.4, 1]
    z_range = [-0.2, 0.8]
    
    shoulder_trace = []
    elbow_trace = []
    wrist_trace = []
    hand_trace = []
    
    def update(val):
        nonlocal shoulder_trace, elbow_trace, wrist_trace, hand_trace

        time_index = int(time_slider.val)

        shoulder_x, shoulder_y, shoulder_z = shoulder_position

        # Joint angles
        shoulder_flexion_extension_angle = math.radians(joint_positions_timeline[time_index][1])
        shoulder_internal_external_angle = math.radians(joint_positions_timeline[time_index][2])
        shoulder_abduction_adduction_angle = math.radians(joint_positions_timeline[time_index][3])
        
        elbow_flex_angle = math.radians(joint_positions_timeline[time_index][4])
        
        wrist_pronation_supination_angle = math.radians(joint_positions_timeline[time_index][5])  # Pronation/supination is at index 5
        wrist_flex_angle = math.radians(joint_positions_timeline[time_index][6])
        wrist_abd_angle = math.radians(joint_positions_timeline[time_index][7])

        # Elbow position
        elbow_pos = np.array([
            -humerus_length * math.sin(shoulder_abduction_adduction_angle),  # X coord
            humerus_length * math.sin(shoulder_flexion_extension_angle) * math.cos(shoulder_abduction_adduction_angle),  # Y coord
            -humerus_length * math.cos(shoulder_abduction_adduction_angle) * math.cos(shoulder_flexion_extension_angle)  # Z coord
        ])

        # Apply shoulder internal/external rotation
        shoulder_rot_matrix = rotation_matrix_z(shoulder_internal_external_angle)
        
        elbow_pos_rot = np.dot(shoulder_rot_matrix, elbow_pos)
        elbow_x_rot = shoulder_x + elbow_pos_rot[0]
        elbow_y_rot = shoulder_y + elbow_pos_rot[1]
        elbow_z_rot = shoulder_z + elbow_pos_rot[2]

        # Calculate wrist position based on rotated elbow
        wrist_pos = np.array([
            -forearm_length * math.cos(elbow_flex_angle) * math.sin(shoulder_abduction_adduction_angle),  # X coord
            forearm_length * math.sin(shoulder_flexion_extension_angle + elbow_flex_angle) * math.cos(shoulder_abduction_adduction_angle),  # Y coord
            -forearm_length * math.cos(shoulder_abduction_adduction_angle) * math.cos(shoulder_flexion_extension_angle + elbow_flex_angle)  # Z coord
        ])
        
        wrist_pos_rot = np.dot(shoulder_rot_matrix, wrist_pos)
        wrist_x = elbow_x_rot + wrist_pos_rot[0]
        wrist_y = elbow_y_rot + wrist_pos_rot[1]
        wrist_z = elbow_z_rot + wrist_pos_rot[2]
        
        # Calculate hand position based on rotated wrist including pronation/supination
        hand_pos = np.array([
            -hand_length * math.sin(wrist_abd_angle + shoulder_abduction_adduction_angle) * math.cos(shoulder_flexion_extension_angle),  # X coord
            hand_length * math.sin(shoulder_flexion_extension_angle + elbow_flex_angle + wrist_flex_angle) * math.cos(shoulder_abduction_adduction_angle),  # Y coord
            -hand_length * (math.cos(shoulder_flexion_extension_angle + elbow_flex_angle + wrist_flex_angle) * math.cos(shoulder_abduction_adduction_angle + wrist_abd_angle + shoulder_abduction_adduction_angle))  # Z coord
        ])
        
        # Apply wrist pronation/supination
        wrist_pronation_matrix = rotation_matrix_y(wrist_pronation_supination_angle)

        hand_pos_rot = np.dot(wrist_pronation_matrix, hand_pos)
        
        # Final hand position
        hand_x = wrist_x + hand_pos_rot[0]
        hand_y = wrist_y + hand_pos_rot[1]
        hand_z = wrist_z + hand_pos_rot[2]

        # Tracing positions over time to visualize the trajectory
        shoulder_trace.append([shoulder_x, shoulder_y, shoulder_z])
        elbow_trace.append([elbow_x_rot, elbow_y_rot, elbow_z_rot])
        wrist_trace.append([wrist_x, wrist_y, wrist_z])
        hand_trace.append([hand_x, hand_y, hand_z])

        # Clearing previous dots to remove lag
        ax.cla()

        # Plotting
        ax.plot([point[0] for point in shoulder_trace], [point[1] for point in shoulder_trace], [point[2] for point in shoulder_trace], c='r', label='Shoulder Joint')
        ax.plot([point[0] for point in elbow_trace], [point[1] for point in elbow_trace], [point[2] for point in elbow_trace], c='b', label='Elbow Joint')
        ax.plot([point[0] for point in wrist_trace], [point[1] for point in wrist_trace], [point[2] for point in wrist_trace], c='g', label='Wrist Joint')
        ax.plot([point[0] for point in hand_trace], [point[1] for point in hand_trace], [point[2] for point in hand_trace], c='y', label='Hand Tip')
        
        ax.scatter(shoulder_x, shoulder_y, shoulder_z, c='r', marker='o')
        ax.scatter(elbow_x_rot, elbow_y_rot, elbow_z_rot, c='b', marker='o')
        ax.scatter(wrist_x, wrist_y, wrist_z, c='g', marker='o')
        ax.scatter(hand_x, hand_y, hand_z, c='y', marker='o')

        # Plotting humerus and forearm
        ax.plot([shoulder_x, elbow_x_rot], [shoulder_y, elbow_y_rot], [shoulder_z, elbow_z_rot], c='k', linestyle='--')
        ax.plot([elbow_x_rot, wrist_x], [elbow_y_rot, wrist_y], [elbow_z_rot, wrist_z], c='k', linestyle='--')
        ax.plot([wrist_x, hand_x], [wrist_y, hand_y], [wrist_z, hand_z], c='k', linestyle='--')

        ax.set_xlabel('X Axis')
        ax.set_ylabel('Y Axis')
        ax.set_zlabel('Z Axis')

        ax.set_title('Joint Positions Over Time')
        ax.legend()

        ax.set_xlim(x_range)
        ax.set_ylim(y_range)
        ax.set_zlim(z_range)

        fig.canvas.draw_idle()

    time_slider.on_changed(update)
    
    plt.show()
    
def forward_kinematics(J2, J3, J4, J5, J6, J7, J8, L1, L2, L3):
    # Simplified forward kinematics for illustrative purposes
    x = (L1 * np.cos(J3) * np.cos(J2) +
         L2 * np.cos(J3 + J4) * np.cos(J2 + J6) +
         L3 * np.cos(J3 + J4 + J5 + J7) * np.cos(J2 + J6 + J8))
    
    y = (L1 * np.sin(J3) +
         L2 * np.sin(J3 + J4) +
         L3 * np.sin(J3 + J4 + J5 + J7))
    
    z = (L1 * np.cos(J3) * np.sin(J2) +
         L2 * np.cos(J3 + J4) * np.sin(J2 + J6) +
         L3 * np.cos(J3 + J4 + J5 + J7) * np.sin(J2 + J6 + J8))
    
    return x, y, z

# Rotation Matrices
def KW():
    shoulder_position, elbow_position, wrist_position, humerus_length, forearm_length, hand_length = endpoints()
    
    L1 = humerus_length
    L2 = forearm_length
    L3 = hand_length
    
    # Adjust the number of samples for each joint range
    num_samples = 5 # Reduced for demonstration purposes
    
    J2_range = np.linspace(-np.radians(90), np.radians(90), num_samples)  # INT/EXT rotation about Z-axis
    J3_range = np.linspace(0, np.radians(180), num_samples)  # ABD/ADD rotation about X-axis
    J4_range = np.linspace(-np.radians(180), np.radians(60), num_samples)  # FLEX/EXT rotation about Y-axis
    J5_range = np.linspace(0, np.radians(140), num_samples)  # FLEX/EXT rotation about Y-axis
    J6_range = np.linspace(-np.radians(80), np.radians(80), num_samples)  # INT/EXT rotation about Z-axis
    J7_range = np.linspace(0, np.radians(60), num_samples)  # FLEX/EXT rotation about X-axis
    J8_range = np.linspace(-np.radians(20), np.radians(30), num_samples)  # ABD/ADD rotation about Y-axis
    
    x_positions = []
    y_positions = []
    z_positions = []
    
    for J2 in J2_range:
        for J3 in J3_range:
            for J4 in J4_range:
                for J5 in J5_range:
                    for J6 in J6_range:
                        for J7 in J7_range:
                            for J8 in J8_range:
                                # Forward kinematics calculation
                                x, y, z = forward_kinematics(J2, J3, J4, J5, J6, J7, J8, L1, L2, L3)
                                x_positions.append(x)
                                y_positions.append(y)
                                z_positions.append(z)
    
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    scatter = ax.scatter(x_positions, y_positions, z_positions, s=1, c='grey', alpha=0.5)  # Changed color to grey and decreased alpha for visibility
    ax.set_xlabel('X [M]')
    ax.set_ylabel('Y [M]')
    ax.set_zlabel('Z [M]')
    ax.set_title('Kinematic Workspace')
    plt.show()

def real_data(testmodel, physicsClient, modelStartPos, modelStartOrientation):
    print("Fitting joint angle data")

    ##reading data in 

    ##These data sets are for the reaching forward task or participants 10 and 4, both randomly selected of the group
    datapath = "H:/Simulation_files/Sim_enviroments/UE_ADLdatabase_Joint_angles/UE_ADLdatabase-master/ADL010/ADL010FR1angles.csv"
    ##datapath = "H:/Simulation_files/Sim_enviroments/UE_ADLdatabase_Joint_angles/UE_ADLdatabase-master/ADL004/ADL004FR1angles.csv"

    ##datapath = "G:/Simulation_files/Sim_enviroments/UE_ADLdatabase_Joint_angles/UE_ADLdatabase-master/ADL010/ADL010CR1angles.csv"
    ##datapath = "G:/Simulation_files/Sim_enviroments/UE_ADLdatabase_Joint_angles/UE_ADLdatabase-master/ADL010/ADL010CR1angles.csv"

    ##these data sets are for the drinking task of participants 10 and 4, both randomly selected of the group


    data = pd.read_csv(datapath)
    
    ##For resting pose
    sim_phase3 = 2
    time_steps = 0.01
    num_steps_phase3 = int(sim_phase3 / time_steps)
    
    ##obtain information about model
    p.resetBasePositionAndOrientation(testmodel, modelStartPos, modelStartOrientation)
    joint_positions_timeline = []
    joint_com_cartesian_coordinates_timeline = []
    shoulder_position, elbow_position, wrist_position, humerus_length, forearm_length, hand_length = endpoints()

    # print("DataFrame structure:")
    # print(data.head())
    # print(data.columns)

    ##Their ordering with print out verifier:
    # Column 5: Shoulder horiz abd-adduction
    # Column 6: Shoulder flexion-extension
    # Column 7: Shoulder internal-external rotation
    # Column 8: Elbow flexion-extension
    # Column 9: Forearm pronation-supination
    # Column 10: Wrist flexion-extension
    # Column 11: Wrist radial-ulnar deviation

    print("\nThe following prints are the original layout of the dataframe:")
    print("C5:E",data.iloc[0,4] )
    print("C6:F",data.iloc[0,5] )
    print("C7:G",data.iloc[0,6] )
    print("C8:H",data.iloc[0,7] )
    print("C9:I",data.iloc[0,8] )
    print("C10:J",data.iloc[0,9] )
    print("C11:K",data.iloc[0,10] )

    # Create the arrays and map the columns right columns
    j1 = data.iloc[:, 5].values  
    j2 = data.iloc[:, 6].values  
    j3 = data.iloc[:, 4].values  
    j4 = data.iloc[:, 7].values  
    j5 = data.iloc[:, 8].values  
    j6 = data.iloc[:, 9].values  
    j7 = data.iloc[:, 10].values  
    
    # Print the first row of each array to verify correct read in with correct columns directed to right arrays
    print("\nThe following statments are arranged to pair the right column with right model joint")
    print("j1 (first row of: flex/ex):", j1[0])
    print("j2 (first row of: Int/Ext):", j2[0])
    print("j3 (first row of: Abd/Add):", j3[0])
    print("j4 (first row of: flex/ex of Elbow):", j4[0])
    print("j5 (first row of: Int/Ext ):", j5[0])
    print("j6 (first row of: Flex/ex):", j6[0])
    print("j7 (first row of: Abd/Add):", j7[0])

    # Listing joints for automation
    joints = [j1, j2, j3, j4, j5, j6, j7]
    joint_names = ['j1', 'j2', 'j3', 'j4', 'j5', 'j6', 'j7']

        # Key for movement direction requirements
    movement_key = {
        "j1_positive": "Positive", "j1_negative": "Negative",
        "j2_positive": "Positive", "j2_negative": "Negative",
        "j3_positive": "Positive", "j3_negative": "Negative",
        "j4_positive": "Positive", "j4_negative": "Negative",
        "j5_positive": "Positive", "j5_negative": "Negative",
        "j6_positive": "Positive", "j6_negative": "Negative",
        "j7_positive": "Positive", "j7_negative": "Negative"
    }
    
    """
    # Key for movement direction requirements
    movement_key = {
        "Shoulder_flexion": "Negative",
        "Shoulder_extension": "Positive",

        "Shoulder_IntRotation": "Positive",
        "Shoulder_ExtRotation": "Negative",

        "Shoulder_abduction": "Positive",
        "Shoulder_adduction": "Negative",

        "Elbow_Flexion": "Negative",
        "Elbow_Extension": "Positive",

        "Wrist_IntRotation": "Positive",
        "Wrist_ExtRotation": "Negative",

        "Wrist_flexion": "Positive",
        "Wrist_Extension": "Negative",

        "Wrist_Abduction": "Positive",
        "Wrist_Adduction": "Negative"
    }
    """

    # Movement flags dictionary (single boolean for each joint) to allow for user to specify what movements would be occuring to apporpriately insert any data into model.
    # True for Values of that joint to be negative, False for positive
    # Dictionarys to indicate whether to use original values for each joint as some values have both negative and positive values

    #     ##the following flag is for the Drinking task, true values keep the angular difference negative producing a movement of the joint that uses naegative values
    # movement_flags = {
    #     "j1": True,   ##flexion 
    #     "j2": True, ##since original values, this statement dont mattter
    #     "j3": False,
    #     "j4": True,
    #     "j5": False,
    #     "j6": True,
    #     "j7": False
    # }

    # ##the following dictioinary si weather oriinal values are being used for Drinking task
    # use_original_values = {
    #     "j1": False,
    #     "j2": False, ##no major changes, can leave original values as its couple degrees of change
    #     "j3": True,
    #     "j4": False,
    #     "j5": True,  
    #     "j6": True,  
    #     "j7": True   
    # }

        ##the following flag is for the reaching forward task, true values keep the angular difference negative producing a movement of the joint that uses naegative values
    movement_flags = {
        "j1": True,  
        "j2": False,
        "j3": False,
        "j4": False,
        "j5": True,
        "j6": True,
        "j7": False
    }

    ##the following dictioinary si weather oriinal values are being used for the reaching forward task
    use_original_values = {
        "j1": False,
        "j2": True,
        "j3": False,
        "j4": False,
        "j5": True,  # Use original values
        "j6": True,  # Use original values
        "j7": True   # Use original values
    }

    # Function to calculate angular changes for each joint by comparing each row's change
    def calculate_angular_changes(joint_data):
        angular_change = []  # Each row's change appends here

        for i in range(1, len(joint_data)):
            change = joint_data[i] - joint_data[i - 1]  # Difference/joint change
            angular_change.append(change)

        return angular_change  # For use later on

    # Add up the differences to generate a total sum of angular change
    def calculate_total_angular_changes(angular_changes):
        total_angular_change = []  # List for them
        total_angular_change_v = 0

        for change in angular_changes:  # For each joint so it works iteratively/automatically
            total_angular_change_v += change
            total_angular_change.append(total_angular_change_v)
        return total_angular_change

    # Dictionaries to store angular changes and total angular changes for each joint
    angular_changes_dict = {}
    total_angular_changes_dict = {}
    print_messages = []  # List to store print messages


    # Calculate and store angular changes and total angular changes for each joint
    for i, joint in enumerate(joints):
        # Calculate the changes in angles between each consecutive pair of data points for the current joint
        angular_changes = calculate_angular_changes(joint)
        
        # Determine the movement flag and key corresponding to the current joint
        joint_name = joint_names[i]
        flag = movement_flags[joint_name]
        
        # Convert angular changes based on movement flags and direction
        if not use_original_values[joint_name]:
            if flag:  # If True, make changes negative
                angular_changes = [-abs(change) for change in angular_changes]
            else:  # If False, make changes positive
                angular_changes = [abs(change) for change in angular_changes]
        
        # Calculate the cumulative sum of angular changes iteratively for the current joint
        total_angular_changes = calculate_total_angular_changes(angular_changes)
        
        # Store the angular changes and total angular changes in dictionaries, using the joint name as the key
        angular_changes_dict[joint_name] = angular_changes
        total_angular_changes_dict[joint_name] = total_angular_changes

        # Print the total angular changes for the current joint
        print_messages.append(f"\nTotal angular change for {joint_name}: {total_angular_changes}")

    """
    Resting Pose of Model to exact of study:
    0 = flexion/Extension
    -5 = Slight External Rotation
    0 = Abd/Add
    -90 = Elbow Flexion
    0 = No wrist movments at base

    J1 = 0
    J2 = -5
    J3 = 0
    J4 = -90
    J5 = 0
    J6 = 0
    J7 = 0

    """
    ##initial positions, resting pose of participants
    initial_positions = {
        'j1': 0,
        'j2': -5,
        'j3': 0,
        'j4': -90,
        'j5': 0,
        'j6': 0,
        'j7': 0
    }
    ##Joint number/indexing
    joint_indices = {
        'j1': 1,
        'j2': 2,
        'j3': 3,
        'j4': 4,
        'j5': 5,
        'j6': 6,
        'j7': 7
    }

    ## Phase 1: resting pose of hand on table
    for _ in range(num_steps_phase3):
        joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
        joint_positions_timeline.append(joint_positions)
        # joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
        # Set initial positions
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-5), positionGain=0.02)
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-90), positionGain=0.02)
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
        p.stepSimulation()
        time.sleep(0.01)

    ##Phase 2, impliment the angular change as angles to model joints to insert motions
    for time_step in range(len(next(iter(total_angular_changes_dict.values())))):  # Using the length of one of the joint's total angular changes
        for joint_name, total_angular_changes in total_angular_changes_dict.items():
            joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
            joint_positions_timeline.append(joint_positions)

            target_position = initial_positions[joint_name] + total_angular_changes[time_step] ##adds the joint change to the resting pose to create smooth transition
            
            p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=joint_indices[joint_name], controlMode=p.POSITION_CONTROL, targetPosition=math.radians(target_position))   ##joint mover
        
        p.stepSimulation()
        time.sleep(0.01)
    

    for message in print_messages:
        print(message)
    # Call the trajectory function to plot the movement
    trajectory(joint_positions_timeline, humerus_length, forearm_length, shoulder_position, hand_length)
    angle_plotting(joint_positions_timeline, figsize=(8, 6))

    
    return joint_positions_timeline, joint_com_cartesian_coordinates_timeline

def raw_data(testmodel, physicsClient, modelStartPos, modelStartOrientation):
    print("Fitting joint angle data")

    # Reading data in
    datapath = "H:/Simulation_files/Sim_enviroments/UE_ADLdatabase_Joint_angles/UE_ADLdatabase-master/ADL010/ADL010FR1angles.csv"
    ##datapath = "H:/Simulation_files/Sim_enviroments/UE_ADLdatabase_Joint_angles/UE_ADLdatabase-master/ADL004/ADL004FR1angles.csv"
    data = pd.read_csv(datapath)
    
    # For resting pose
    sim_phase3 = 2
    time_steps = 0.01
    num_steps_phase3 = int(sim_phase3 / time_steps)
    
    # Obtain information about the model
    p.resetBasePositionAndOrientation(testmodel, modelStartPos, modelStartOrientation)
    joint_positions_timeline = []
    joint_com_cartesian_coordinates_timeline = []
    
    # Listing the joint data arrays corresponding to the columns
    j1 = data.iloc[:, 5].values  # Shoulder flexion-extension
    j2 = data.iloc[:, 6].values  # Shoulder internal-external rotation
    j3 = data.iloc[:, 4].values  # Shoulder abduction-adduction
    j4 = data.iloc[:, 7].values  # Elbow flexion-extension
    j5 = data.iloc[:, 8].values  # Forearm pronation-supination
    j6 = data.iloc[:, 9].values  # Wrist flexion-extension
    j7 = data.iloc[:, 10].values  # Wrist radial-ulnar deviation
    
    # Listing joints for automation
    joints = [j1, j2, j3, j4, j5, j6, j7]
    joint_names = ['Shoulder Flexion-Extension', 'Shoulder Int-Ext Rotation', 
                   'Shoulder Abduction-Adduction', 'Elbow Flexion-Extension', 
                   'Forearm Pronation-Supination', 'Wrist Flexion-Extension', 
                   'Wrist Radial-Ulnar Deviation']

    print("\nThe following prints are the original layout of the dataframe:")
    print("C5:E", data.iloc[0, 4])
    print("C6:F", data.iloc[0, 5])
    print("C7:G", data.iloc[0, 6])
    print("C8:H", data.iloc[0, 7])
    print("C9:I", data.iloc[0, 8])
    print("C10:J", data.iloc[0, 9])
    print("C11:K", data.iloc[0, 10])

    # Print the first row of each array to verify correct read in with correct columns directed to right arrays
    print("\nThe following statements are arranged to pair the right column with the right model joint")
    print("j1 (first row of: flex/ex):", j1[0])
    print("j2 (first row of: Int/Ext):", j2[0])
    print("j3 (first row of: Abd/Add):", j3[0])
    print("j4 (first row of: flex/ex of Elbow):", j4[0])
    print("j5 (first row of: Int/Ext):", j5[0])
    print("j6 (first row of: Flex/ex):", j6[0])
    print("j7 (first row of: Abd/Add):", j7[0])

    # Plotting each joint's angle values over time
    time_steps = range(len(j1))  # Assuming uniform time steps across data points
    
    plt.figure(figsize=(10, 8))
    
    for i, joint in enumerate(joints):
        plt.plot(time_steps, joint, label=joint_names[i])  # Plot joint values over time

        # Calculate total angular change for each joint
        total_angular_change = joint[-1] - joint[0]
        print(f"Total angular change for {joint_names[i]}: {total_angular_change:.2f} degrees")

        # Annotate the total angular change at the bottom of the graph
        plt.text(len(time_steps) * 0.8, -15 - i * 10, 
                 f'{joint_names[i]} Change: {total_angular_change:.2f}°', 
                 fontsize=10, color='black', 
                 bbox=dict(facecolor='white', alpha=0.7))

    plt.title("Joint Angles Over Time")
    plt.xlabel("Time Steps")
    plt.ylabel("Joint Angle (Degrees)")
    plt.legend()
    plt.grid(True)
    plt.show()
    
    return joint_positions_timeline, joint_com_cartesian_coordinates_timeline

def Bicep_curl(physicsClient, modelStartPos, modelStartOrientation, testmodel, joint_names):
    
    simduration_phase1 = 1  #  phase 1
    simduration_phase2 = 1  #  phase 2 etc...
    sim_phase3 = 1
    sim_phase4 = 1
    time_steps = 0.01
    
    num_steps_phase1 = int(simduration_phase1 / time_steps) ##amouint of time/steps in phase etc..
    num_steps_phase2 = int(simduration_phase2 / time_steps)
    num_steps_phase3 = int(sim_phase3 / time_steps)
    num_steps_phase4 = int(sim_phase4 / time_steps)
    
    p.resetBasePositionAndOrientation(testmodel, modelStartPos, modelStartOrientation)
    joint_positions_timeline = []
    joint_torques_timeline = []
    joint_reaction_forces_timeline = []
    joint_com_cartesian_coordinates_timeline = []
    
    shoulder_position, elbow_position, wrist_position, humerus_length, forearm_length, hand_length = endpoints()
    
    
        # Phase 2: testing
    for _ in range(num_steps_phase3):
        joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
        joint_positions_timeline.append(joint_positions)
        joint_torques_timeline.append(joint_torques)
        joint_reaction_forces_timeline.append(joint_reaction_forces)
        joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-90), positionGain=0.02)
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
        p.stepSimulation()
        time.sleep(0.01)
        
    #Phase 1:  testing
    for _ in range(num_steps_phase1):
        joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
        joint_positions_timeline.append(joint_positions)
        joint_torques_timeline.append(joint_torques)
        joint_reaction_forces_timeline.append(joint_reaction_forces)
        joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ##flexion/extension
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ##internal/external rotation
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ##abduction/adduction
        
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-90), positionGain=0.02) ##Flexion/extension
        
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ##internal/external rotation
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(45), positionGain=0.02) ##flexi/ex
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ## ulnar and radial deviation
        
        p.stepSimulation()
        time.sleep(0.01)

        #Phase 1:  testing
    for _ in range(num_steps_phase1):
        joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
        joint_positions_timeline.append(joint_positions)
        joint_torques_timeline.append(joint_torques)
        joint_reaction_forces_timeline.append(joint_reaction_forces)
        joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ##flexion/extension
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ##internal/external rotation
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ##abduction/adduction
        
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-90), positionGain=0.02) ##Flexion/extension
        
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(45), positionGain=0.02) ##internal/external rotation
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(45), positionGain=0.02) ##flexi/ex
        p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ## ulnar and radial deviation
        
        p.stepSimulation()
        time.sleep(0.01)
        
    """
    Shoulder joint:
    Joint 2: humerus_joint_roll Index=1  flexion/extension
    Joint 3: humerus_joint_yaw Index=2 internal/external rotation
    Joint 4: humerus_joint Index=3 abduction/adduction

    Elbow joint:
    Joint 5: elbow_joint Index=4 Flexion/extension

    Wrist joint:
    Joint 6: wrist_joint_roll index=5  internal/external rotation
    Joint 7: wrist_joint_yaw Index=6 flexion/extension
    Joint 8: wrist_joint Index=7 abduction/adduction
    """

    # # Phase 2: resting pose
    # for _ in range(num_steps_phase3):
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
    
    
    # ##Phase 1:  Shoulder abduction
    # for _ in range(num_steps_phase1):
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(45), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
    
    # # Phase 2: rests
    # for _ in range(num_steps_phase3):
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)

    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
        
        
    # # Phase 3: shoulder flexion
    # for _ in range(num_steps_phase3):
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-45), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
        
    # for _ in range(num_steps_phase3): ##resting
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
        
        
    # for _ in range(num_steps_phase3): ##Elbow flexion
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-90), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
        
    # for _ in range(num_steps_phase3): ##shoulder rotation
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-45), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-90), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
        
        
        
    # for _ in range(num_steps_phase3): ##resting
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
        
    # for _ in range(num_steps_phase3): ## hand extension
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-45), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)

    #         # Phase 2: testing
    # for _ in range(num_steps_phase3):
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-90), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
        
    # #Phase 1:  resting
    # for _ in range(num_steps_phase1):
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ##flexion/extension
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ##internal/external rotation
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ##abduction/adduction
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-90), positionGain=0.02) ##Flexion/extension
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(45), positionGain=0.02) ##internal/external rotation
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ##flexi/ex
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02) ## ulnar and radial deviation
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
        
    # for _ in range(num_steps_phase3): ##pronation
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
        
    # for _ in range(num_steps_phase3): ## hand Abduction
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(45), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
        
    # for _ in range(num_steps_phase3): ##resting
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)
        
    # for _ in range(num_steps_phase3): ## hand Extension and Elbow flexion
    #     joint_positions, joint_torques, joint_reaction_forces, joint_cartesian_coordinates = joint_info(testmodel, time_steps)
    #     joint_positions_timeline.append(joint_positions)
    #     joint_torques_timeline.append(joint_torques)
    #     joint_reaction_forces_timeline.append(joint_reaction_forces)
    #     joint_com_cartesian_coordinates_timeline.append(joint_cartesian_coordinates)
        
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=1, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=2, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=3, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=4, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-90), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=5, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=6, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(-45), positionGain=0.02)
    #     p.setJointMotorControl2(bodyUniqueId=testmodel, jointIndex=7, controlMode=p.POSITION_CONTROL, targetPosition=math.radians(0), positionGain=0.02)
        
    #     p.stepSimulation()
    #     time.sleep(0.01)

        
    # Call the trajectory function to plot the movement
    trajectory(joint_positions_timeline, humerus_length, forearm_length, shoulder_position, hand_length)
    ##call after storing to let the function do it automatically

    #plot_motor_torque_over_time(joint_torques_timeline, figsize=(8, 6))
    angle_plotting(joint_positions_timeline, figsize=(8, 6))
    
    return joint_positions_timeline, joint_torques_timeline, joint_reaction_forces_timeline, joint_com_cartesian_coordinates_timeline

def main():
    # print("Please select which arm motion you would like:")
    # print("1. 90 Degree bicep curl")

    #user_choice = input("\nPlease enter your choice: 1: ")
    
    physicsClient = p.connect(p.GUI)
    modelStartPos, modelStartOrientation, testmodel = simulation_model()
    time_step = 0.01

    ##KW()
    ##^ kinematic workspace

    real_data(testmodel, physicsClient, modelStartPos, modelStartOrientation) ##comment this one in to use implimented data
    raw_data(testmodel, physicsClient, modelStartPos, modelStartOrientation)
    joint_names = joint_info(testmodel, time_step)
    ##just for jiont info

    ##joint_positions_timeline, joint_torques_timeline, joint_reaction_forces_timeline, joint_com_cartesian_coordinates_timeline = Bicep_curl(physicsClient, modelStartPos, modelStartOrientation, testmodel, joint_names)
    ##^ comment this one in if you want to manually test the model yourself.

    # Keep the simulation running
    while True:
        p.stepSimulation()

main()